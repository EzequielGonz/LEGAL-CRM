function normalizeHeader(h: string): string {
  return h
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // saca acentos (rango unicode de tildes)
    .toLowerCase()
    .replace(/[^a-z0-9]/g, ""); // saca espacios, guiones, slashes, etc.
}

const ALIASES: Record<string, string[]> = {
  full_name: [
    "nombre",
    "nombreapellido",
    "nombrecompleto",
    "fullname",
    "name",
    "apellidoynombre",
    "nombreyapellido",
    "apelidoynombre", // typo común: "apellido" con una sola "l" (así vino una planilla real)
  ],
  phone: [
    "telefono",
    "phone",
    "celular",
    "whatsapp",
    "tel",
    "numero",
    "numerodetelefono",
    "movil",
    "wsp",
    "cel",
    "celu",
    "nrotelefono",
    "nrocelular",
    "numerodecelular",
    "numerodewhatsapp",
    "telefonocelular",
    "telefonomovil",
  ],
  email: ["email", "correo", "mail", "correoelectronico"],
  dni_cuil: ["dni", "cuil", "dnicuil", "documento", "cuit"],
  tipo_de_consulta: ["tipodeconsulta", "tipoconsulta", "consulta", "motivo", "motivodeconsulta"],
  fecha_de_consulta: ["fechadeconsulta", "fechaconsulta", "fecha"],
  observaciones: ["observaciones", "notas", "comentarios", "observacion"],
  // El barrio/zona del prospecto — en las planillas reales viene bajo la
  // columna "Localidad".
  localidad: ["localidad", "barrio", "zona", "localidadbarrio", "ciudad"],
  // El tipo de lesión (para priorizar el envío de campañas, ver
  // computeCampaignPriority en ./priority.ts). En las planillas reales de
  // ART/aseguradoras viene bajo la columna "DIAGNOSTICO" — pero se suman
  // alias por si en otra planilla viene bajo un nombre distinto.
  diagnostico: ["diagnostico", "diagnosticomedico", "lesion", "tipodelesion", "lesiones"],
  // Para Coberturas Médicas: de qué obra social/prepaga viene el contacto
  // ANTES de la propuesta de cambio (no la que se le recomienda, esa la
  // define el agente de IA). Útil tanto para que el bot no se la vuelva a
  // preguntar si ya vino en la planilla, como para filtrar/analizar la base.
  obra_social_actual: [
    "obrasocial",
    "obrasocialactual",
    "prepaga",
    "coberturamedica",
    "coberturaactual",
    "obrasocialoprepaga",
  ],
};

// Para el teléfono en particular (el dato que más importa reconocer bien:
// sin él, no hay a quién mandarle el mensaje) sumamos un segundo intento
// más permisivo: si ninguno de los alias exactos matchea, buscamos que el
// nombre de columna CONTENGA una de estas palabras clave. A diferencia de
// "nombre" o "consulta", una columna que menciona teléfono/celular/
// whatsapp/móvil casi nunca se refiere a otra cosa en una planilla de
// contactos, así que el riesgo de falso positivo es bajo — esto cubre
// headers más largos como "Teléfono de contacto" o "Número de Whatsapp"
// que no son un alias exacto pero sí contienen la palabra clave.
const PHONE_CONTAINS_TOKENS = ["telefono", "whatsapp", "celular", "movil"];

// Mismo respaldo que el teléfono, pero para el nombre: si ninguno de los
// alias exactos matchea (por ejemplo, un typo distinto al que ya se
// contempló arriba), se acepta cualquier columna que CONTENGA "nombre".
// Es un poco menos preciso que el de teléfono (podría matchear una columna
// rara tipo "Nombre del estudio"), pero en la práctica una planilla de
// contactos casi siempre tiene como mucho una columna con "nombre" en el
// header, así que vale la pena como último recurso antes de dejarlo vacío.
const FULL_NAME_CONTAINS_TOKENS = ["nombre"];

/** Columnas elegidas a mano en la importación (null = detección automática). */
export interface ColumnMapping {
  phone?: string | null;
  name?: string | null;
  dni?: string | null;
}

/**
 * Propone qué columna del archivo corresponde a teléfono, nombre y DNI, con
 * el mismo criterio que usa la lectura fila por fila (alias exactos y, para
 * teléfono y nombre, columnas que contienen la palabra clave). Se muestra
 * como propuesta: la persona puede corregirla antes de guardar.
 */
export function detectColumns(headers: string[]): { phone: string | null; name: string | null; dni: string | null } {
  const norm = headers.map((h) => [h, normalizeHeader(h)] as const);
  const byAlias = (field: keyof typeof ALIASES) => {
    for (const alias of ALIASES[field]) {
      const hit = norm.find(([, n]) => n === alias);
      if (hit) return hit[0];
    }
    return null;
  };
  const byToken = (tokens: string[]) => norm.find(([, n]) => tokens.some((t) => n.includes(t)))?.[0] ?? null;
  return {
    phone: byAlias("phone") ?? byToken(PHONE_CONTAINS_TOKENS),
    name: byAlias("full_name") ?? byToken(FULL_NAME_CONTAINS_TOKENS),
    dni: byAlias("dni_cuil"),
  };
}

/** Lectura de una fila con las columnas elegidas a mano por encima de la detección. */
export function resolveRowFields(rawRow: Record<string, unknown>, mapping?: ColumnMapping | null): ExtractedRowFields {
  const fields = extractRowFields(rawRow);
  const pick = (col?: string | null) => {
    if (!col) return undefined;
    const v = rawRow[col];
    return v === undefined || v === null || String(v).trim() === "" ? null : String(v).trim();
  };
  if (mapping?.phone) fields.phone_raw = pick(mapping.phone) ?? null;
  if (mapping?.name) fields.full_name = pick(mapping.name) ?? null;
  if (mapping?.dni) fields.dni_cuil = pick(mapping.dni) ?? null;
  return fields;
}

export interface ExtractedRowFields {
  full_name: string | null;
  phone_raw: string | null;
  email: string | null;
  dni_cuil: string | null;
  tipo_de_consulta: string | null;
  fecha_de_consulta: string | null;
  observaciones: string | null;
  localidad: string | null;
  diagnostico: string | null;
  obra_social_actual: string | null;
}

/**
 * Interpreta una fila cruda (tal como vino del CSV/Excel, con los headers
 * originales como claves) usando alias de nombres de columna comunes en
 * español, sin importar mayúsculas/acentos/espacios.
 */
export function extractRowFields(rawRow: Record<string, unknown>): ExtractedRowFields {
  const normalizedEntries = Object.entries(rawRow).map(
    ([key, value]) => [normalizeHeader(key), value] as const
  );

  function cellValue(match: readonly [string, unknown] | undefined): string | null {
    if (match && match[1] !== undefined && match[1] !== null && String(match[1]).trim() !== "") {
      return String(match[1]).trim();
    }
    return null;
  }

  function findField(field: keyof typeof ALIASES): string | null {
    for (const alias of ALIASES[field]) {
      const value = cellValue(normalizedEntries.find(([key]) => key === alias));
      if (value !== null) return value;
    }
    return null;
  }

  function findPhoneField(): string | null {
    const exact = findField("phone");
    if (exact !== null) return exact;
    // Respaldo: columna que CONTIENE una palabra clave de teléfono aunque
    // no sea un alias exacto (ver PHONE_CONTAINS_TOKENS arriba).
    const match = normalizedEntries.find(([key]) =>
      PHONE_CONTAINS_TOKENS.some((token) => key.includes(token))
    );
    return cellValue(match);
  }

  function findFullNameField(): string | null {
    const exact = findField("full_name");
    if (exact !== null) return exact;
    const match = normalizedEntries.find(([key]) =>
      FULL_NAME_CONTAINS_TOKENS.some((token) => key.includes(token))
    );
    return cellValue(match);
  }

  return {
    full_name: findFullNameField(),
    phone_raw: findPhoneField(),
    email: findField("email"),
    dni_cuil: findField("dni_cuil"),
    tipo_de_consulta: findField("tipo_de_consulta"),
    fecha_de_consulta: findField("fecha_de_consulta"),
    observaciones: findField("observaciones"),
    localidad: findField("localidad"),
    diagnostico: findField("diagnostico"),
    obra_social_actual: findField("obra_social_actual"),
  };
}
